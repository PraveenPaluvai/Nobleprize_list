import NobelPrizesList from './NobelPrizesList';
export default NobelPrizesList;
