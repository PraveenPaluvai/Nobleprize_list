import NobelPrizeModal from './NobelPrizeModal';
export default NobelPrizeModal;
