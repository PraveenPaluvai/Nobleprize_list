import NobelPrizeItem from './NobelPrizeItem';
export default NobelPrizeItem;
