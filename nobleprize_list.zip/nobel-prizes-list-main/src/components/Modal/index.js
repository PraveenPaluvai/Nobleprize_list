import Modal from './Modal';
export default Modal;
