// eslint-disable-next-line no-undef
export const API_BASE_URL = process.env.REACT_APP_NOBEL_PRIZE_API_BASE_URL;
